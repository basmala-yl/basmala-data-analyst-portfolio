# Basmala Ahmed Mahmoud — Data Analyst Portfolio

Light professional portfolio website built with HTML, CSS and JavaScript.

## Included
- Light, professional visual identity
- Professional portrait section
- USP section
- Linked project pages
- Full-size dashboard galleries with click-to-zoom lightbox
- View CV and Download CV buttons
- Amazon, Seoudi Market and Global Insights projects
- Responsive layout for desktop/tablet/mobile

## Run in Visual Studio Code
1. Open this folder in VS Code.
2. Install the Live Server extension.
3. Right-click `index.html` → Open with Live Server.
4. Use the navigation cards to open each project page.

No Node.js, React or npm is required.


## Adding the new dashboards later
The project pages already contain clearly marked placeholders for the dashboard images that are not uploaded yet:
- Country: Economic Performance
- Country: Country Details & Drill Through
- Country: Key Insights
- Seoudi: Home / Executive Overview

When the images are available, put them in `assets/` and replace the corresponding placeholder block in the matching project HTML page. The existing full-screen click-to-zoom gallery will work automatically.
